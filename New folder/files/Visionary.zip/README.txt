
  ////////////////
  // Visionary! //
  ////////////////

By Ryan Magliola, Piet Braun, and Alli Efaw
Ryan.Magliola@gmail.com
http://maglio.la

Experience the thrill of extending your creativity into the next generation with Visionary! Construct your secretly chosen word to your viewers as they try to guess what your masterpiece resembles.
Playable with the HTC Vive
2+ players recommended, someone using the Vive and an audience of more than one.

Have fun!

Notes:
Even if the server is not running, it will still show an ID, and you will still be able to access the website. Despite this, online functionality will not work.

Changelog 5-26-2017:
Added paint buckets around pillar. Dip/Stir an object in it to dye it that color. Mix colors together if desired.

  ////////////////
  // Visionary! //
  ////////////////

Unauthorized distribution of this software is prohibited. This build if Visionary is available for FREE at http://maglio.la
If you paid for this software or received it as part of a bundle, you have been scammed and should demand a refund.
Unauthorized viewing and/or modification to Visionary's source code is prohibited.